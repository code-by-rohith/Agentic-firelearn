# RAG tool implementations.
